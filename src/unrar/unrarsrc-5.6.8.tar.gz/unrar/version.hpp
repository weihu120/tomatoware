#define RARVER_MAJOR     5
#define RARVER_MINOR    61
#define RARVER_BETA      0
#define RARVER_DAY      30
#define RARVER_MONTH     9
#define RARVER_YEAR   2018
