#ifndef _RAR_LANG_
#define _RAR_LANG_

  #ifdef USE_RC
    #include "rarres.hpp"
  #else
    #include "loclang.hpp"
  #endif

#endif
